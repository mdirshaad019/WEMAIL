<?php
		echo "he";
		$email=$_GET['id'];
		echo $email;
?>